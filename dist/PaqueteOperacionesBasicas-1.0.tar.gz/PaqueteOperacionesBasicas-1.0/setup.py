from setuptools import setup
setup(
    name="PaqueteOperacionesBasicas",
    version="1.0",
    description="Paquete de suma y resta",
    author="Jorge Antonio",
    author_email="jorgezunigarojas1@gmail.com",
    url="www.msci.com",
    packeges=["paquete_calculos"]
)